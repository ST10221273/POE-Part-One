/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part1;

import java.util.Scanner;
/**
 *
 * @author thato
 */
public class Part1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        String username = null;
        String password = null;
        String name;
        String surname;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter your name");
        name = input.nextLine();
        
        System.out.println("Enter your surname");
        surname = input.nextLine();
        
        System.out.println("Enter your username");
        username = input.nextLine();
        
        System.out.println("Enter youe password");
        password = input.nextLine();
        
        if(username.equals("Therealtee") && (password.equals("Thatongwako_13"))){
            System.out.println("Welcome " + name +" "+ surname + " it is great to see you again");
        }
        else{
            System.out.println("Username or password is incorrect, please try again");
        }
        
    }
    public static boolean username(int username){
        
         if (username > 0){
             return true;
         }
         else{
             return false;
         }
         
             
    }
    
     public static boolean password(int password){
        
         if (password > 0){
             return true;
         }
         else{
             return false;
         }
         
             
    }
}
